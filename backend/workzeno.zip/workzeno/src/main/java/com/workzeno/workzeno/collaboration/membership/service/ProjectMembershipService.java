package com.workzeno.workzeno.collaboration.membership.service;
import com.workzeno.workzeno.collaboration.membership.domain.ProjectMembership;
import com.workzeno.workzeno.collaboration.membership.domain.ProjectMembershipRole;
import com.workzeno.workzeno.collaboration.membership.dto.*;
import com.workzeno.workzeno.collaboration.membership.mapper.ProjectMembershipMapper;
import com.workzeno.workzeno.collaboration.membership.repository.ProjectMembershipRepository;
import com.workzeno.workzeno.identity.security.service.CurrentUserProvider;
import com.workzeno.workzeno.identity.user.domain.User;
import com.workzeno.workzeno.identity.user.repository.UserRepository;
import com.workzeno.workzeno.projects.domain.Project;
import com.workzeno.workzeno.projects.domain.ProjectStatus;
import com.workzeno.workzeno.projects.service.ProjectAccessService;
import com.workzeno.workzeno.projects.service.ProjectModificationPolicy;
import com.workzeno.workzeno.shared.exception.ApiException;
import com.workzeno.workzeno.tasks.repository.TaskAssigneeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.dao.DataIntegrityViolationException;
import org.hibernate.exception.ConstraintViolationException;
import com.workzeno.workzeno.collaboration.membership.api.MembershipManagement;
import com.workzeno.workzeno.collaboration.membership.api.ProjectAuthorization;


import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ProjectMembershipService implements MembershipManagement {

    private final ProjectMembershipRepository membershipRepository;
    private final UserRepository userRepository;
    private final CurrentUserProvider currentUserProvider;
    private final ProjectAuthorization authorizationService;
    private final ProjectAccessService projectAccessService;
    private final ProjectMembershipMapper membershipMapper;
    private final TaskAssigneeRepository taskAssigneeRepository;
    ProjectModificationPolicy projectModificationPolicy;

    @Transactional
    public void addMember(UUID projectId, AddProjectMemberRequest request) {
        UUID currentUserId = getCurrentUserId();
        Project project = loadActiveProject(projectId, currentUserId);

        ensureRoleIsProvided(request.role());

        authorizeMemberAddition(project, currentUserId, request.role());

        ensureOwnerIsNotTarget(project, request.userId());


        if (membershipRepository.existsByProjectIdAndUserId(projectId, request.userId())) {
            throw membershipAlreadyExists();
        }

        User user = loadUser(request.userId());

        ProjectMembership membership = new ProjectMembership(
                project,
                user,
                request.role()
        );

        try {
            //Save and flush the membership to ensure that any constraint violations are caught immediately
            membershipRepository.saveAndFlush(membership);

        } catch (DataIntegrityViolationException exception) {

            if (isDuplicateMembershipViolation(exception)) {
                throw membershipAlreadyExists();
            }

            throw exception;
        }
    }

    @Transactional
    public void changeMemberRole(
            UUID projectId,
            UUID targetUserId,
            UpdateProjectMemberRoleRequest request
    ) {
        UUID currentUserId = getCurrentUserId();
        Project project = loadActiveProject(projectId, currentUserId);

        authorizationService.requireOwner(project, currentUserId);
        ensureOwnerIsNotTarget(project, targetUserId);

        ProjectMembership membership =
                loadMembership(projectId, targetUserId);

        ensureRoleIsProvided(request.role());
        membership.changeRole(request.role());
    }


    @Transactional
    public void removeMember(UUID projectId, UUID targetUserId) {

        UUID currentUserId = getCurrentUserId();

        Project project = loadActiveProject(
                projectId,
                currentUserId
        );

        // Preserve the existing authorization policy.
        authorizationService.requireOwnerOrAdmin(
                project,
                currentUserId
        );

        ensureOwnerIsNotTarget(project, targetUserId);

        ProjectMembership membership = loadMembership(
                projectId,
                targetUserId
        );

        ensureAdminCanOnlyBeRemovedByOwner(
                project,
                membership,
                currentUserId
        );

        /*
         * Step 1:
         * Delete every task assignment belonging to this member
         * inside this project.
         *
         * This must happen before deleting the membership because
         * the database foreign key uses ON DELETE NO ACTION.
         */
        taskAssigneeRepository.deleteAllByProjectIdAndUserId(
                projectId,
                targetUserId
        );

        /*
         * Step 2:
         * Now it is safe to delete the membership.
         *
         * Tasks and comments are not deleted.
         */
        membershipRepository.delete(membership);
    }

    public Page<ProjectMemberResponse> getProjectMembers(
            UUID projectId,
            Pageable pageable
    ) {
        UUID currentUserId = getCurrentUserId();

        projectAccessService.loadAccessibleProject(
                projectId,
                currentUserId
        );

        return membershipRepository
                .findAllByProjectIdOrderByJoinedAtDesc(projectId, pageable)
                .map(membershipMapper::toProjectMemberResponse);
    }

    /**
     * Searches the current project's members for assignment suggestions.
     *
     * The caller must have access to the project.
     * Only actual project members are returned, not the project owner
     * or unrelated users.
     */
    public List<ProjectMemberResponse> searchProjectMembers(
            UUID projectId,
            String search,
            int limit
    ) {

        UUID currentUserId = getCurrentUserId();

        projectAccessService.loadAccessibleProject(
                projectId,
                currentUserId
        );

        String normalizedSearch = search.trim().toLowerCase(
                java.util.Locale.ROOT
        );

        List<ProjectMembership> memberships =
                membershipRepository.searchMembersByEmail(
                        projectId,
                        normalizedSearch,
                        Pageable.ofSize(limit)
                );

        return memberships.stream()
                .map(membershipMapper::toProjectMemberResponse)
                .toList();
    }


    public ProjectTeamResponse getProjectTeam(
            UUID projectId,
            Pageable pageable
    ) {
        UUID currentUserId = getCurrentUserId();

        Project project = projectAccessService.loadAccessibleProject(
                projectId,
                currentUserId
        );

        var ownerResponse = membershipMapper.toProjectOwnerResponse(
                project.getOwner()
        );

        Page<ProjectMemberResponse> members =
                membershipRepository
                        .findAllByProjectIdOrderByJoinedAtDesc(
                                projectId,
                                pageable
                        )
                        .map(membershipMapper::toProjectMemberResponse);

        return new ProjectTeamResponse(
                ownerResponse,
                members
        );
    }


    // --------------------------------------------------
    // Public Membership Management API
    // --------------------------------------------------
    @Override
    public boolean isMember(UUID projectId, UUID userId) {
        return membershipRepository.existsByProjectIdAndUserId(
                projectId,
                userId
        );
    }

    @Override
    @Transactional
    public void addMemberFromInvitation(
            Project project,
            User user,
            ProjectMembershipRole role
    ) {
        if (project == null || user == null) {
            throw new IllegalArgumentException(
                    "Project and user are required"
            );
        }

        projectModificationPolicy.requireActive(project, "Membership");
        ensureRoleIsProvided(role);
        ensureOwnerIsNotTarget(project, user.getId());

        if (isMember(project.getId(), user.getId())) {
            throw membershipAlreadyExists();
        }

        ProjectMembership membership = new ProjectMembership(
                project,
                user,
                role
        );

        try {
            // Flush immediately so the database's unique constraint
            // is checked while this method is executing.
            membershipRepository.saveAndFlush(membership);

        } catch (DataIntegrityViolationException exception) {

            if (isDuplicateMembershipViolation(exception)) {
                throw membershipAlreadyExists();
            }

            throw exception;
        }
    }

    public MyProjectMembershipResponse getMyProjectMembership(
            UUID projectId
    ) {
        UUID currentUserId = getCurrentUserId();

        projectAccessService.loadAccessibleProject(
                projectId,
                currentUserId
        );

        ProjectMembershipRole role = membershipRepository
                .findRoleByProjectIdAndUserId(projectId, currentUserId)
                .orElseThrow(() -> new ApiException(
                        HttpStatus.NOT_FOUND,
                        "Membership not found",
                        "Your project membership could not be found"
                ));

        return new MyProjectMembershipResponse(projectId, role);
    }

    // --------------------------------------------------
    // Shared helper methods
    // --------------------------------------------------

    private UUID getCurrentUserId() {
        return currentUserProvider.getCurrentUserId();
    }

    private Project loadActiveProject(UUID projectId, UUID currentUserId) {
        Project project = projectAccessService.loadAccessibleProject(
                projectId,
                currentUserId
        );

        projectModificationPolicy.requireActive(project, "Membership");

        return project;
    }

    private void authorizeMemberAddition(
            Project project,
            UUID currentUserId,
            ProjectMembershipRole role
    ) {
        if (role == null) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid membership role",
                    "A membership role is required"
            );
        }

        // If the role of the member being added is ADMIN, only the project owner can add them.
        if (role == ProjectMembershipRole.ADMIN) {
            authorizationService.requireOwner(project, currentUserId);
            return;
        }

        authorizationService.requireOwnerOrAdmin(project, currentUserId);
    }

    private void ensureOwnerIsNotTarget(Project project, UUID targetUserId) {
        if (Objects.equals(project.getOwner().getId(), targetUserId)) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid membership",
                    "The project owner cannot be managed as a member"
            );
        }
    }

    private User loadUser(UUID userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ApiException(
                        HttpStatus.NOT_FOUND,
                        "User not found",
                        "The requested user does not exist"
                ));
    }

    private ProjectMembership loadMembership(
            UUID projectId,
            UUID targetUserId
    ) {
        return membershipRepository
                .findByProjectIdAndUserIdForUpdate(projectId, targetUserId)
                .orElseThrow(() -> new ApiException(
                        HttpStatus.NOT_FOUND,
                        "Membership not found",
                        "The requested user is not a member of this project"
                ));
    }
    private void ensureAdminCanOnlyBeRemovedByOwner(
            Project project,
            ProjectMembership membership,
            UUID currentUserId
    ) {
        boolean targetIsAdmin =
                membership.getRole() == ProjectMembershipRole.ADMIN;

        boolean currentUserIsOwner =
                Objects.equals(project.getOwner().getId(), currentUserId);

        if (targetIsAdmin && !currentUserIsOwner) {
            throw new ApiException(
                    HttpStatus.FORBIDDEN,
                    "Forbidden",
                    "Only the project owner can remove an admin"
            );
        }
    }



    private ApiException membershipAlreadyExists() {
        return new ApiException(
                HttpStatus.CONFLICT,
                "Membership conflict",
                "This user is already a member of the project"
        );
    }

    private boolean isDuplicateMembershipViolation(Throwable exception) {
        Throwable current = exception;

        while (current != null) {

            if (current instanceof ConstraintViolationException violation) {
                return "uq_project_memberships_project_user"
                        .equalsIgnoreCase(violation.getConstraintName());
            }

            current = current.getCause();
        }

        return false;
    }

    private void ensureRoleIsProvided(ProjectMembershipRole role) {
        if (role == null) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid membership role",
                    "A membership role is required"
            );
        }
    }

}
