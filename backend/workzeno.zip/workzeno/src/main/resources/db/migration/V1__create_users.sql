CREATE TABLE users (
id UUID PRIMARY KEY,
email VARCHAR(254) NOT NULL,
password_hash VARCHAR(255) NOT NULL,
role VARCHAR(20) NOT NULL DEFAULT 'USER',
status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
CONSTRAINT uq_users_email UNIQUE (email),

CONSTRAINT ck_users_email_normalized
    CHECK (email = LOWER(BTRIM(email))),

CONSTRAINT ck_users_role
    CHECK (role IN ('USER', 'ADMIN')),

CONSTRAINT ck_users_status
    CHECK (status IN ('ACTIVE', 'DISABLED', 'LOCKED'))
);
